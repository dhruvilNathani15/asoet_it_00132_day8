var x=50,y=20;
var z = x+y;
var x=50,y=20;
var a = x-y;
var x=30,y=10;
var b = x*y;

console.log("sum of  x+y is:",z);
document.write("<br>")
document.write("sum of x+y is:",z);


console.log("sum of x-y is",a);
document.write("<br>")
document.write("sum of x-y is:",a);

console.log("sum of x*y is",b);
document.write("<br>")
document.write("sum of x*y is:",b);